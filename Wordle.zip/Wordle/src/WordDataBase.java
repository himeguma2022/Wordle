import java.io.*;
import java.util.Scanner;
public class WordDataBase {
    private String[] SuperDataBase;
    private String[] Common;
    public static void main(String[] args) {
        WordDataBase demo = new WordDataBase();
    }
    public WordDataBase(){
        try {  
            // Create f1 object of the file to read data  
            File f1 = new File("C:\\Users\\himeg\\Documents\\Wordle\\Wordle\\src\\Scrable.txt");    
            Scanner dataReader = new Scanner(f1);
            int words = 0;  
            while (dataReader.hasNextLine()) {  
                String fileData = dataReader.nextLine(); 
                words++;
            }  
            dataReader.close(); 
            SuperDataBase = new String[words];
            f1 = new File("C:\\Users\\himeg\\Documents\\Wordle\\Wordle\\src\\Scrable.txt");    
            dataReader = new Scanner(f1);
            for(int i = 0; i < words; ++i){
                SuperDataBase[i] = dataReader.nextLine().toLowerCase(); 
            }

        } catch (FileNotFoundException exception) {  
            System.out.println("Unexcpected error occurred!");  
            exception.printStackTrace();  
        }
        try {  
            // Create f1 object of the file to read data  
            File f1 = new File("C:\\Users\\himeg\\Documents\\Wordle\\Wordle\\src\\oneThousandMostCommon.txt");    
            Scanner dataReader = new Scanner(f1);
            int words = 0;  
            while (dataReader.hasNextLine()) {  
                String fileData = dataReader.nextLine(); 
                words++;
            }  
            dataReader.close(); 
            Common = new String[words];
            f1 = new File("C:\\Users\\himeg\\Documents\\Wordle\\Wordle\\src\\oneThousandMostCommon.txt");    
            dataReader = new Scanner(f1);
            for(int i = 0; i < words; ++i){
                Common[i] = dataReader.nextLine().toLowerCase(); 
            }

        } catch (FileNotFoundException exception) {  
            System.out.println("Unexcpected error occurred!");  
            exception.printStackTrace();  
        }
    }
    public String[] getSuperDataBase(){
        return SuperDataBase;
    }

    public String[] getCommon(){
        return Common;
    }
}