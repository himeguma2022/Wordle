public class Word {
    private String content;
    private char[] chars;
    private char[] contains;
    
    public static void main(String[] args) {
        test("apple");
        test("banana");
        test("white");
        test("question");
        test("book");
        test("leetcode");
    }

    private static void test(String string) {
        Word test = new Word(string);
        System.out.print(test.content + "->\t");
        for(int i = 0; i < test.chars.length; ++i){
            System.out.print("\t["+test.chars[i]+"]");
        }
        System.out.print("\n\t");
        for(int i = 0; i < test.contains.length; ++i){
            System.out.print("\t["+test.contains[i]+"]");
        }
        System.out.print("\n");
    }

    public Word(String stuff){
        content =  stuff;
        chars = stringToArray(stuff);
        contains = containArray(stringToArray(stuff));
    }

    private char[] containArray(char[] set) {
        set = sort(set);
        set = removeDuplicates(set);
        return set;
    }

    private char[] removeDuplicates(char[] set) {
        int newSize = 1;
        for(int i = 1; i < set.length; ++i){
            if(set[i] == set[i-1]){
                set[i-1] = '1';
            }
            else{
                ++newSize;
            }
        }
        char[] temp = new char[newSize];
        int assignTo = 0;
        for(int i = 0; i < set.length; ++i){
            if(set[i] != '1'){
                temp[assignTo] = set[i];
                ++assignTo;
            }
        }
        return temp;
    }

    private char[] sort(char[] set) {
        char[] temp = new char[set.length];
        for(int i = 0; i < set.length; ++i){
            for(int j = i + 1; j < set.length; ++j){
                if(set[i] > set[j]){
                    temp[i] = set[i];
                    set[i] = set[j];
                    set[j] = temp[i];
                }
            }
            temp[i] = set[i];
        }
        return temp;
    }

    private char[] stringToArray(String stuff) {
        char[] output = new char[stuff.length()];
        for(int i = 0; i < output.length; ++i){
            output[i] = stuff.charAt(0);
            stuff = stuff.substring(1);
        }
        return output;
    }

    public char[] getContains(){
        return contains;
    }

    public char[] getChars(){
        return chars;
    }

    public String getContent(){
        return content;
    }
}
