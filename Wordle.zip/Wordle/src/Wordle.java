import java.util.*;
public class Wordle {
    private String correct;
    private int turnCount;
    private LetterBoard letters;
    private boolean solved;
    private static boolean humanInput = true;
    private static boolean easyMode = true;
    private static boolean simulating = false;

    public static void main(String[] args) {
        WordDataBase possibleAnswers = new WordDataBase();
        startUp(possibleAnswers);
    }
    public Wordle(){
        WordDataBase possibleAnswers = new WordDataBase();
        startUp(possibleAnswers);
    }
    
    public Wordle(String correct, WordDataBase using){
        this.correct = correct;
        turnCount = 0;
        letters = new LetterBoard();
        solved = false;
        turn(using);
    }

    private void turn(WordDataBase using) {
        String input = "";
        if(!simulating){
            System.out.println("Attempt " +(turnCount+1));
            System.out.println("Guess a word that is "+correct.length()+" letters long, or type GIVE UP to quit.");
        }
        if(humanInput){
            input = acceptHumanInput(using);
        } else{
            System.out.println("AI not ready yet :(");
            System.exit(0);
        }
        if(input.equals("GIVE UP")){
            System.out.println("You gave up after "+(turnCount + 1)+" turns.");
            System.out.println("The word we were looking for was "+correct+".");
        }
        else{
            GuessAndResult attempt = new GuessAndResult(new Word(correct), new Word(input));
            ++turnCount;
            if(!simulating){
                attempt.CharInfo();
                for(int i = 0; i < attempt.getCorrectPos().length; ++i){
                    System.out.print("Letter in position " + (i+1) + " is ");
                    if(attempt.getCorrectPos()[i]){
                        System.out.print("Correct. ");
                    } else{
                        System.out.print("Wrong. ");
                    }
                    System.out.print("\n");
                }
            }
            letters.Update(attempt.getCorrectCharsArray(), attempt.getCharShared(), attempt.getCharNotPresent());
            if(!simulating){
                letters.displayBoard();
            }
            if(attempt.getSolved()){
                System.out.println("You solved it after "+ turnCount+" turns.");
                solved = true;
            } else{
                System.out.println("Try again...");
                turn(using);
            }
        }
    }

    private String acceptHumanInput(WordDataBase using) {
        Scanner sc= new Scanner(System.in);
        String check = sc.nextLine();
        if(check.equals("GIVE UP")){
            return check;
        }
        if(check.length() != correct.length()){
            System.out.println("Guess a word that is "+correct.length()+" letters long...");
            return acceptHumanInput(using);
        }
        for(int i = 0; i < check.length(); ++i){
            if(!Character.isLowerCase(check.charAt(i))){
                System.out.println("Guess a word that is "+correct.length()+" letters long...");
                return acceptHumanInput(using);
            }
        }
        for(int i = 0; i < using.getSuperDataBase().length; ++i){
            if(check.equals(using.getSuperDataBase()[i])){
                return check;
            }
        }
        System.out.println("Guess a word that is "+correct.length()+" letters long...");
        return acceptHumanInput(using);
    }
    public static void startGame(String key, WordDataBase using){
        Wordle demo = new Wordle(key, using);
        if(!simulating){
            System.out.println("Play again? Type N to quit.");
            Scanner sc= new Scanner(System.in);
            String check = sc.nextLine();
            if(check.equals("N")){
                System.exit(0);
            }
        }
        startUp(using);

    }
    private static void startUp(WordDataBase using) {
        int chosenNumber = 5;
        if(!simulating){
            System.out.println("How long do you want the word to guess to be?");
            chosenNumber = checkNumber();
        }
        String choose;
        if(easyMode){
        choose = chooseWord(chosenNumber, using.getCommon());
        }
        else{
            choose = chooseWord(chosenNumber, using.getSuperDataBase());
        }
        startGame(choose, using);
        
        
    }
    private static String chooseWord(int chosenNumber, String[] superDataBase) {
        int magicNumber = (int)(superDataBase.length*Math.random());
        if(superDataBase[magicNumber].length()==chosenNumber){
            return superDataBase[magicNumber];
        }
        return chooseWord(chosenNumber, superDataBase);
    }
    private static int checkNumber() {
        System.out.println("Words can only be between two to ten characters long...");
        Scanner sc = new Scanner(System.in);
        int check;
        try{
            check = sc.nextInt();
        } catch(InputMismatchException e){
            System.out.println("Words can only be between two to ten characters long...");
        return checkNumber();
        }
        if(check > 1 && check <11){
            return check;
        }
        System.out.println("Words can only be between two to ten characters long...");
        return checkNumber();
    }
}
